﻿/* Main angular app
 -  Declared UserProfile service to handle user module.
*/

(function () {
    // myApp object 
    var app = angular.module('loanGrantSearchApp',[]);

})();